<?php
set_time_limit(0);

require_once($_SERVER["DOCUMENT_ROOT"] . '/interface/globals.php');
require_once("$srcdir/acl.inc");
use OpenEMR\Common\Csrf\CsrfUtils;
use OpenEMR\Core\Header;

if (!acl_check('admin', 'super')) {
  die(xlt('Not authorized'));
}

$response = '';
$success = array();
$records = array();
$tableHeading = array();


if(isset($_POST["submit"])) {
  if (!CsrfUtils::verifyCsrfToken($_POST["csrf_token_form"])) {
    CsrfUtils::csrfNotVerified();
  }

  if(isset($_FILES['file']['tmp_name']) && (isset($_FILES["file"]["name"]) && $_FILES["file"]["name"]) ) {

    $currentDate=date('Y-m-d H:i:s');
    $parts = pathinfo($_FILES["file"]["name"]);
    $extension = strtolower($parts['extension']);
    if($extension=='csv') {

      $filePath = $_FILES['file']['tmp_name'];
      $file = fopen($filePath,"r");
      $entries = array();

      $i=1; while(!feof($file)) {
        $row = fgetcsv($file);
        if($i==1) {

          /* TABLE HEADING */
          foreach($row as $k=>$v) {
            $tableHeading[$k]=$v;
          }

        } else {

          /* TABLE ROWS */
          if( is_array($row) && array_filter($row) ) {
            $args = [];
            foreach($row as $key=>$val) {
              if( isset($tableHeading[$key]) ) {
                $val = preg_replace("/\s+/"," ",$val);
                $index = $tableHeading[$key];
                $args[$index]=$val;
              }
            }
            if($args) {
              $entries[] = $args;
            }
          }

        }

        $i++;
      }

      fclose($file);


      /* INSERT DATA */
      if( $entries ) {
        $n=0; foreach($entries as $col=>$val) {

          /* Search if CODE does not exists */
          $data_code = ($val['code']) ?  strtoupper($val['code']) : '';
          $data_code = ($data_code) ?  preg_replace("/\s+/"," ",$data_code) : '';

          $modifier = ($val['modifier']) ?  strtoupper($val['modifier']) : '';
          $modifier = ($modifier) ? preg_replace("/\s+/"," ",$modifier) : '';

          $en = $val;
          $en['is_duplicate'] = '';

          //$temp_sql_ret = sqlQuery("SELECT `id` FROM `users` WHERE `username` = ?", array($_POST['authUser']));

          /* Check if code already exists */
          $sql_search = "SELECT code FROM codes WHERE code='".$data_code."'";
          
          if($modifier && preg_replace("/\s+/","",$modifier)) {
            
            $is_exist = sqlQuery("SELECT `code` FROM `codes` WHERE `code` = ? AND `modifier` = ?", array($data_code,$modifier));
            if($is_exist) {
              $en['is_duplicate'] = array('code'=>$data_code,'modifier'=>$modifier);
            }

          } else {
            $is_exist = sqlQuery("SELECT `code` FROM `codes` WHERE `code` = ?", array($data_code));
            if($is_exist) {
              $en['is_duplicate'] = array('code'=>$data_code,'modifier'=>'');
            }
          }

          if( !$en['is_duplicate'] ) {
            $fee = ( $val['fee'] && preg_replace("/\s+/","",$val['fee']) ) ? preg_replace("/\s+/"," ",$val['fee']) : '';
            $fee = ($fee && preg_replace("/\s+/","",$fee) ) ? number_format((float)$fee, 2, '.', '') : NULL;

            $sqlData = array(
              'code'=>$data_code,
              'code_text'=>trim($val['code_text']),
              'code_type'=>'1',
              'modifier'=>$modifier,
              'fee'=>$fee,
              'revenue_code'=>$val['revenue_code'],
              'financial_reporting'=>1,
              'active'=>1
            );


            $tableFields = array();
            $tableValues = array();
            foreach($sqlData as $k=>$v) {
              $tableFields[] = $k;
              $tableValues[] = "'".$v."'";

            }

            $sql_codes = "INSERT INTO codes (".implode(', ',$tableFields).") VALUES (".implode(', ',$tableValues).")";
            $prices = '';
            if($fee) {
              $feeArr['standard'] = $fee;
              $prices = json_encode($feeArr);
            } 


            $sqlDataHistory = array(
              'code'=>$data_code,
              'code_text'=>trim($val['code_text']),
              'modifier'=>$modifier,
              'code_type_name'=>'CPT4 Procedure/Service',
              'action_type'=>'new',
              'prices'=>$prices,
              'date'=>$currentDate,
              'financial_reporting'=>1,
              'active'=>1,
              'update_by'=>$_SESSION['authUser']
            );

            $tableFieldsHistory = array();
            $tableValuesHistory = array();
            foreach($sqlDataHistory as $k=>$v) {
              $tableFieldsHistory[] = $k;
              $tableValuesHistory[] = "'".$v."'";
            }
            
            $code_new_id = sqlInsert($sql_codes);
            if( $code_new_id ) {
              $success['codes'] = $code_new_id;
              if($fee) {
                $sql_price = "INSERT INTO prices (pr_id,pr_level,pr_price) VALUES ($code_new_id,'standard',$fee)";
                $price_new_id = sqlInsert($sql_price);
              }

              $sql_codes_history = "INSERT INTO codes_history (".implode(', ',$tableFieldsHistory).") VALUES (".implode(', ',$tableValuesHistory).")";
              if( $historyId = sqlInsert($sql_codes_history) ) {
                $success['codes_history'] = $historyId;
              }
            }
          }

          $records[] = $en;

          $n++;
        }
      }

      if( $success ) {
        $response = '<div class="alert alert-success" role="alert"><i class="fa fa-check"></i> Data imported successfully.</div>';
      }

    } else {
      $response = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Invalid file format.</div>';
    }
  } else {
    $response = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Upload a CSV file.</div>';
  }

}
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo xlt('Import Codes'); ?></title>
  <link rel="stylesheet" href="../../public/assets/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../public/assets/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href='<?php echo $css_header ?>' type='text/css'>
  <style>
    .alert, .alert-custom {
      font-size: 1em;
      font-weight: bold;
    }
    .alert.alert-success {
      color: #3c763d!important;
    }
    .container {
      max-width: 1000px;
      width: 100%;
    }
    .formwrap {
      max-width: 660px;
      width: 100%;
      margin: 0 auto 30px;
      padding-top: 5%;
    }
    .formwrap h1 {
      font-size: 2em;
    }
    table.result {
      border:1px solid #DDD;
    }
    table.result tbody td {
      font-size: 13px;
      line-height: 1.2;
    }
    tr.duplicate th,
    tr.duplicate td {
      color: red;
    }
    tbody th[scope="row"] {
      color: #7f7f7f;
      font-weight: normal;
    }
    tbody td {vertical-align:middle;}
    tbody td span.stat {
      display: block;
      width: 100%;
      text-align: center;
      font-size: 0.85em;
      line-height: 1;
    }
    tbody td span.stat.duplicate {
      color: red;
    }
    tbody td span.stat.ok {
      color: green;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="formwrap">
    <?php if ($response) { ?>
    <div class="message"><?php echo $response ?></div>  
    <?php } ?>
    <h1>Import Codes</h1>
    <div class="well center-block">
      <form action="<?php echo $rootdir; ?>/misc/import-codes.php" method="post" enctype="multipart/form-data" class="navbar-form">
        <input type="hidden" name="csrf_token_form" value="<?php echo attr(CsrfUtils::collectCsrfToken()); ?>" />
        <div class="input-group">
          <span class="input-group-addon" id="fileinfo">Browse CSV file:</span>
          <input type="file" id="file" class="form-control" name="file" aria-describedby="fileinfo" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
        </div>
        <div class="form-group">
          <input type="submit" value="Upload File" name="submit" class="btn btn-success" />
        </div>
      </form>
    </div>
  </div>

  <?php if ($records) { ?>
    <table class="table result">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <?php foreach ($tableHeading as $head) { ?>
          <th scope="col"><?php echo $head ?></th>
          <?php } ?>
          <th scope="col">inserted</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $ctr=1; foreach ($records as $values) {
        $code =  $values['code'];
        $isDuplicate = (isset($values['is_duplicate']) && $values['is_duplicate']) ? 'duplicate' : 'ok';
        ?>
        <tr class="<?php echo $isDuplicate ?>">
          <th scope="row"><?php echo $ctr ?></th>
          <?php foreach ($values as $k=>$v) { 
            if($k=='is_duplicate') {
              if($v) {
                $v='<span class="stat duplicate">DUPLICATE</span>';
              } else {
                $v='<span class="stat ok">OK</span>';
              }
            }
            ?>
            <td><?php echo $v ?></td>  
          <?php } ?>
        </tr>
        <?php $ctr++; } ?>
      </tbody>
    </table>
  <?php } ?>
</div>

</body>
</html>